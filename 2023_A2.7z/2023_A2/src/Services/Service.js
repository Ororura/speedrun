import Web3 from "web3";
import abi from "./abi.json";

class Service {
  contractAddress = "0x4ba0147e642479344051C7c2859aEa5b6C37e739";
  web3 = new Web3("http://localhost:8545");
  contract = new this.web3.eth.Contract(abi, this.contractAddress);

  getTime = async () => {
    try {
      return await this.contract.methods.getTime().call();
    } catch (error) {
      console.log(error);
    }
  };

  signIn = async (login, password) => {
    try {
      return await this.contract.methods.signIn(login, password).call();
    } catch (e) {
      console.log(alert("Неверно введённые данные"));
    }
  };

  signUp = async (login, password, wallet) => {
    try {
      return await this.contract.methods
        .signUp(login, password)
        .send({ from: wallet });
    } catch (error) {
      alert(error);
    }
  };

  approveWhitelist = async (id, status, wallet) => {
    try {
      return await this.contract.methods
        .approveWhitelist(id, status)
        .send({ from: wallet });
    } catch (error) {
      console.log(error);
    }
  };

  getUserData = async (address, wallet) => {
    if (this.web3.utils.isAddress(address))
      try {
        return await this.contract.methods
          .getUserData(address)
          .call({ from: wallet });
      } catch (error) {
        console.log(error);
      }
  };

  buyTokens = async (amount, value, wallet) => {
    try {
      return await this.contract.methods
        .buyTokens(amount)
        .send({ from: wallet, value: value });
    } catch (error) {
      alert(error);
    }
  };

  sendTokens = async (amount, address, phase, wallet) => {
    try {
      return await this.contract.methods
        .sendTokens(address, amount, phase)
        .send({ from: wallet });
    } catch (error) {
      alert(error);
    }
  };

  sendWhitelistReq = async (login, address, wallet) => {
    try {
      return await this.contract.methods
        .sendWhitelistReq(login, address)
        .send({ from: wallet });
    } catch (error) {
      alert(error);
    }
  };

  sendReward = async (amount, address, wallet) => {
    try {
      return await this.contract.methods
        .sendWhitelistReq(address, amount)
        .send({ from: wallet });
    } catch (error) {
      alert(error);
    }
  };

  addMinute = async () => {
    try {
      return await this.contract.methods
        .addMinute()
        .send();
    } catch (error) {
      alert(error);
    }
  };

}

export default new Service();
