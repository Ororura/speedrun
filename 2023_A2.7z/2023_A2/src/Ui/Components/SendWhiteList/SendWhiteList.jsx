import React, { useContext, useState } from "react";
import { Form, Button, Card } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";

const SendWhitelistReq = () => {
  const { userData } = useContext(Context);
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.sendWhitelistReq(target[0].value, target[1].value, userData.wallet);
  };
  return (
    <div style={{ width: "70%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>
        Отправить запрос на вайтлист
      </p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите свой логин</Form.Label>
          <Form.Control type="number" placeholder="Токены" />
          <Form.Label>Введите свой адрес</Form.Label>
          <Form.Control type="number" placeholder="Адрес" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Отправить
        </Button>
      </Form>
    </div>
  );
};

export default SendWhitelistReq;
