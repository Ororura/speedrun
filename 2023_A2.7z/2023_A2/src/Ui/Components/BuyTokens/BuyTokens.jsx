import React, { useContext, useState } from "react";
import { Form, Button, Card } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";

const BuyTokens = () => {
  const { userData } = useContext(Context);
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.buyTokens(target[0].value, target[1].value, userData.wallet);
  };
  return (
    <div style={{ width: "70%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>
        Купить токены
      </p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите кол-во токенов</Form.Label>
          <Form.Control type="text" placeholder="Токены" />
          <Form.Label>Введите кол-во эфира</Form.Label>
          <Form.Control type="text" placeholder="Эфир" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Купить
        </Button>
      </Form>
    </div>
  );
};

export default BuyTokens;
