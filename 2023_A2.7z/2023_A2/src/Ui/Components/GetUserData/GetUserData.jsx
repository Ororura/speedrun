import React, { useContext, useState } from "react";
import { Form, Button, Card } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";

const GetUserData = () => {
  const { userData } = useContext(Context);
  const [dataOwner, setData] = useState({
    seedBal: "",
    publicBal: "",
    privateBal: "",
  });
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    const data = await Service.getUserData(target[0].value, userData.wallet);
    setData({
      ...dataOwner,
      seedBal: data[4],
      privateBal: data[5],
      publicBal: data[6],
    });
    console.log(data);
  };
  return (
    <div style={{ width: "70%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>
        Получить данные пользователя
      </p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите адрес</Form.Label>
          <Form.Control type="text" placeholder="Адрес" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Получить
        </Button>
      </Form>
      <Card>
        <Card.Body>
          <Card.Text>Сид баланс: {dataOwner.seedBal}</Card.Text>
          <Card.Text>Приватный баланс: {dataOwner.privateBal}</Card.Text>
          <Card.Text>Паблик баланс: {dataOwner.publicBal}</Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
};

export default GetUserData;
