import React, { useContext, useState } from "react";
import { Form, Button, Card } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";

const SendReward = () => {
  const { userData } = useContext(Context);
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.sendReward(target[0].value, target[1].value, userData.wallet);
  };
  return (
    <div style={{ width: "70%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>
        Отправить награду пользователю
      </p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите кол-во токенов</Form.Label>
          <Form.Control type="number" placeholder="Токены" />
          <Form.Label>Введите адрес</Form.Label>
          <Form.Control type="number" placeholder="Адрес" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Отправить
        </Button>
      </Form>
    </div>
  );
};

export default SendReward;
