import React, { useContext, useEffect, useState } from "react";
import { Card, Button } from "react-bootstrap";
import { Context } from "../../../Core/Context/Context";
import Service from "../../../Services/Service";

const Timers = () => {
  const { userData } = useContext(Context);
  const [time, seTime] = useState(0);
  useEffect(() => {
    (async () => {
      await Service.getTime().then((el) => {
        seTime(Number(el));
      });

    })();
  }, []);

  useEffect(() => {
    const inter = setInterval(() => {
        seTime((prevTime) => prevTime + 1);
      }, 1000);
      return () => {
        clearInterval(inter);
      };
  })

  return (
    <div style={{ width: "30%", margin: "auto", marginTop: "20px" }}>
      <Card>
        <Card.Body>
          <Card.Title>Таймеры</Card.Title>
          <Card.Text>Время старта: {time}</Card.Text>
          <Card.Text>Время приватной фазы {time > 900 ? <> закончилась</> : <>{time}</>} </Card.Text>
          <Card.Text>Время свободной продажи: {time - 900 > 1200 ? <>{time - 900}</>: <>Свободная продажа не началась</>}</Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
};

export default Timers;
