import React, { useContext, useState } from "react";
import { Form, Button, Card } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";

const TimeSkip = () => {
  const { userData } = useContext(Context);
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.addMinute();
  };
  return (
    <div style={{ width: "70%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>
        Ускорить время
      </p>
        <Button variant="primary" type="submit">
          Ускорить
        </Button>
    </div>
  );
};

export default TimeSkip;
