import React from "react";
import { Navbar, Container, Nav, NavDropdown } from "react-bootstrap";
import { Link } from "react-router-dom";

const WithNavBar = (WrappedComponent) => {
  return () => {
    return (
      <>
        <Navbar expand="lg" className="" style={{ backgroundColor: "purple" }}>
          <Container style={{ color: "white" }}>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link>
                  <Link to="/">Личный кабинет</Link>
                </Nav.Link>
                <Nav.Link>
                  <Link to="/login">Авторизация</Link>
                </Nav.Link>
                <Nav.Link>
                  <Link to="/reg">Зарегестрироваться</Link>
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
        {WrappedComponent}
      </>
    );
  };
};

export default WithNavBar;
