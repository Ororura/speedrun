import React, { useContext } from "react";
import { Form, Button } from "react-bootstrap";
import Service from "../../../Services/Service";

const ApproveWhitelist = () => {
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.approveWhitelist(target[0].value, target[1].value);
  };
  return (
    <div style={{ width: "50%", margin: "auto", marginTop: "20px" }}>
      <p style={{ textAlign: "center", fontSize: "30px" }}>Добавить в вайтлист</p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите айди</Form.Label>
          <Form.Control type="number" placeholder="Айди" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Выберите статус</Form.Label>
          <Form.Select aria-label="Default select example">
            <option value="true">Разрешить</option>
            <option value="false">Запретить</option>
          </Form.Select>
        </Form.Group>
        <Button variant="primary" type="submit">
          Отправить
        </Button>
      </Form>
    </div>
  );
};

export default ApproveWhitelist;
