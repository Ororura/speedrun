import React, { useContext, useEffect } from "react";
import WithNavBar from "../../Components/HOC/Header";
import { Card, Button } from "react-bootstrap";
import { Context } from "../../../Core/Context/Context";
import { useHistory } from "react-router-dom";
import ApproveWhitelist from "../../Components/ApproveWhitelist/ApproveWhitelist";
import GetUserData from "../../Components/GetUserData/GetUserData";
import BuyTokens from "../../Components/BuyTokens/BuyTokens";
import Timers from "../../Components/Timers/Timers";
import SendTokens from "../../Components/SendTokens/SendTokens";
import SendWhitelistReq from "../../Components/SendWhiteList/SendWhiteList"
import SendReward from "../../Components/SendReward/SendReward";
import TimeSkip from "../../Components/TimeSkip/TimeSkip";

const Main = () => {
  const { userData } = useContext(Context);
  const navigation = useHistory();

  useEffect(() => {
    if (userData.login === "") {
      navigation.push("/login");
    }
  }, []);

  return (
    <div style={{ width: "30%", margin: "auto", marginTop: "20px" }}>
        <Timers/>
        <TimeSkip></TimeSkip>
      <Card style={{marginTop:"20px"}}>
        <Card.Body>
          <Card.Title>Информация о вашем аккаунте</Card.Title>
          <Card.Text>Логин: {userData.login}</Card.Text>
          <Card.Text>Ваша роль: {userData.role}</Card.Text>
          <Card.Text>
            Вайтлист: {userData.whitelist === true ? <>Есть</> : <>Нет</>}
          </Card.Text>
          <Card.Text>Адрес: {userData.wallet}</Card.Text>
          <Card.Text>Сид баланс: {userData.seedBal}</Card.Text>
          <Card.Text>Приватный баланс: {userData.privateBal}</Card.Text>
          <Card.Text>Паблик баланс: {userData.publicBal}</Card.Text>
        </Card.Body>
      </Card>
      <ApproveWhitelist />
      <GetUserData />
      <BuyTokens/>
      <SendTokens/>
      <SendWhitelistReq/>
      <SendReward></SendReward>
    </div>
  );
};

const WithNavBarMain = WithNavBar(<Main />);

export default WithNavBarMain;
