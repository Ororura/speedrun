import React, { useContext } from "react";
import { Form, Button } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";
import WithNavBar from "../../Components/HOC/Header";
import {useHistory} from "react-router-dom";

const Login = () => {
  const navigation = useHistory();
  const { setData } = useContext(Context);
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    const data = await Service.signIn(target[0].value, target[1].value);
    setData(data);
    navigation.push("/");
  };

  return (
    <div style={{ width: "50%", margin: "auto" }}>
      <p style={{textAlign:"center", fontSize:"30px"}}>Авторизация</p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите логин</Form.Label>
          <Form.Control type="text" placeholder="Логин" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Введите пароль</Form.Label>
          <Form.Control type="password" placeholder="Пароль" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Войти
        </Button>
      </Form>
    </div>
  );
};

const WithNavBarLog = WithNavBar(<Login></Login>);

export default WithNavBarLog;
