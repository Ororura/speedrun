import React, { useContext } from "react";
import { Form, Button } from "react-bootstrap";
import Service from "../../../Services/Service";
import { Context } from "../../../Core/Context/Context";
import WithNavBar from "../../Components/HOC/Header";
import {useHistory} from "react-router-dom";

const Reg = () => {
  const navigation = useHistory();
  const handler = async (e) => {
    e.preventDefault();
    const { target } = e;
    await Service.signUp(target[0].value, target[1].value);
    navigation.push("/login")
  };

  return (
    <div style={{ width: "50%", margin: "auto" }}>
      <p style={{textAlign:"center", fontSize:"30px"}}>Регистрация</p>
      <Form onSubmit={handler}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Введите логин</Form.Label>
          <Form.Control type="text" placeholder="Логин" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Введите пароль</Form.Label>
          <Form.Control type="password" placeholder="Пароль" />
        </Form.Group>
        <Button variant="primary" type="submit">
          Зарегестрироваться
        </Button>
      </Form>
    </div>
  );
};

const WithNavBarReg = WithNavBar(<Reg></Reg>);

export default WithNavBarReg;
