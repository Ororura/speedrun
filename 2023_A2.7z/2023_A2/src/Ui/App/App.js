import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import Service from "../../Services/Service";
import { useEffect } from "react";
import WithNavBarMain from "../Pages/Main/Main";
import { ContextWrapper } from "../../Core/Context/Context";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom"
import Routes from "../../Constants/Routes/Routes";

function App() {
  return (
    <Router>
      <Switch>
      <ContextWrapper>
        {Routes.map((el) => (<Route path={el.path} component={el.component} key={el.path} exact></Route>))}
        </ContextWrapper>
      </Switch>
    </Router>
  );
}

export default App;
