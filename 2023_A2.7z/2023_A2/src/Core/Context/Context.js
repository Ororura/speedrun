import React, { createContext, useState } from "react";

export const Context = createContext({});

export function ContextWrapper({ children }) {
  const [userData, setUserData] = useState({
    login: "",
    role: "",
    whitelist: "",
    wallet: "",
    seedBal: "",
    privateBal: "",
    publicBal: "",
  });

  const setData = (data) => {
    setUserData({
      ...userData,
      login: data[0],
      role: data[1],
      whitelist: data[2],
      wallet: data[3],
      seedBal: data[4],
      privateBal: data[5],
      publicBal: data[6],
    });
  };

  const values = { userData, setData, setUserData };
  return <Context.Provider value={values}>{children}</Context.Provider>;
}
