import WithNavBarMain from "../../Ui/Pages/Main/Main";
import Login from "../../Ui/Pages/Login/Login";
import WithNavBarReg from "../../Ui/Pages/Reg/Reg";
const Routes = [
  { path: "/", component: WithNavBarMain },
  { path: "/login", component: Login },
  { path: "/reg", component: WithNavBarReg },
];

export default Routes;
